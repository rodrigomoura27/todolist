import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet,
TouchableOpacity } from 'react-native';
import * as SQLite from 'expo-sqlite';
export default function App() {
 const [db, setDb] = useState(null);
 const [input, setInput] = useState('');
 const [tarefas, setTarefas] = useState([]);
 useEffect(() => {
 (async () => {
 const database = await SQLite.openDatabaseAsync('database.db');
 setDb(database);
 
 await database.execAsync(`
 CREATE TABLE IF NOT EXISTS tarefas (
 cd_tarefa INTEGER PRIMARY KEY AUTOINCREMENT,
 ds_tarefa TEXT NOT NULL
 );
 `);
 fetchTasks(database);
 })();
 }, );
 const fetchTasks = async (database = db) => {
 if (!database) return;
 const result = await database.getAllAsync('SELECT * FROM tarefas;');
 setTarefas(result);
 };
 const addTask = async () => {
 if (!input.trim() || !db) return;
 await db.runAsync('INSERT INTO tarefas (ds_tarefa) VALUES (?);',
[input]);
 setInput('');
 fetchTasks();
 };
 const clearTasks = async () => {
 if (!db) return;
 await db.runAsync('DELETE FROM tarefas;');
 fetchTasks();
 };
 const removerTarefa = async (id) => {
 if (!db) return;
 await db.runAsync('DELETE FROM tarefas WHERE cd_tarefa = ?;',
[id]);
 fetchTasks();
 };
 const renderItem = ({ item }) => (
 <View style={styles.itemTarefa}>
 <Text style={styles.tarefaTexto}>{item.ds_tarefa}</Text>
 <TouchableOpacity onPress={() => removerTarefa(item.cd_tarefa)}
style={styles.botaoExcluir}>
 <Text style={{ color: 'white' }}>Excluir</Text>
 </TouchableOpacity>
 </View>
 );
 return (
 <View style={styles.container}>
 <Text style={styles.title}>To do List</Text>
 <View style={styles.containerInput}>
 <TextInput
 style={styles.input}
 placeholder="Digite uma tarefa"
 value={input}
 onChangeText={setInput}
 />
 <TouchableOpacity style={styles.addButton} onPress={addTask}>
 <Text style={{ color: 'white'}}>Adicionar</Text>
 </TouchableOpacity>
 </View>
 <TouchableOpacity style={styles.apagarTodas} onPress={clearTasks}
color="red"><Text style={{ color: 'white'}}>Limpar
Todas</Text></TouchableOpacity>
 <FlatList
 data={tarefas}
 keyExtractor={item => item.cd_tarefa.toString()}
 renderItem={renderItem}
 style={{ padding: 15}}
 />
 </View>
 );
}
const styles = StyleSheet.create({
 container: {
 flex: 1,
 paddingTop: 60,
 paddingHorizontal: 20,
 backgroundColor: '#f4f4f4',
 },
 title: {
 fontSize: 22,
 fontWeight: 'bold',
 marginBottom: 20,
 textAlign: 'center',
 },
 containerInput: {
 flexDirection: 'row',
 marginBottom: 15,
 alignItems: 'center',
 },
 input: {
 flex: 1,
 borderColor: 'white',
 borderWidth: 1,
 padding: 10,
 marginRight: 10,
 borderRadius: 5,
 backgroundColor: '#fff',
 },
 addButton: {
 backgroundColor: 'blue',
 borderWidth: 1,
 padding: 10,
 marginRight: 10,
 borderRadius: 5,
 borderColor: 'white'
 },
 itemTarefa: {
 flexDirection: 'row',
 justifyContent: 'space-between',
 backgroundColor: 'white',
 borderWidth: 1,
 padding: 10,
 marginRight: 10,
 borderRadius: 5,
 },
 tarefaTexto: {
 flex: 1,
 fontSize: 16,
 },
 botaoExcluir: {
 backgroundColor: 'blue',
 paddingVertical: 6,
 paddingHorizontal: 12,
 borderRadius: 5,
 },
 apagarTodas:{
 backgroundColor: 'black',
 borderWidth: 1,
 padding: 10,
 marginRight: 10,
 borderRadius: 5,
 borderColor: 'white'
 }
});